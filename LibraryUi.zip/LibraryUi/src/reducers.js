import { combineReducers  } from 'redux'
import bookStore from './reducers/reducer'

export default combineReducers({
    bookStore
})