import React, { Component } from 'react';
import { connect } from 'react-redux';
import Modal from 'react-modal';
import { getLibraryBooks, editBook,createNewBook } from './actions/index';
import { filter } from 'lodash';
import './App.css';


class BooksList extends Component {

    constructor(props) {
        super(props);
        this.state = {
            items: [],
            search: '',
            name: '',
            count: '',
            description: '',
            author: '',
            show: false,
            id:''
        }
        this.handleUpdate = this.handleUpdate.bind(this);
    }
    componentDidMount() {
        fetch('http://localhost:2000/products/getBooks', {
            method: 'get'
        }).then(res => res.json())
            .then(data => {
                this.props.getLibraryBooks(data);
                this.setState({ items: data })
            });
    }

    updateItem(item) {
        console.log('item', item)
        this.setState({ show: true,id:item._id, name: item.bookName, description: item.bookDescription, count: item.count, author: item.author })
    }

    bookNameChange(e) {
        this.setState({ name: e.target.value })
    }
    bookDescriptionChange(e) {
        this.setState({ description: e.target.value })
    }
    bookCountChange(e) {
        this.setState({ count: e.target.value })
    }
    bookAuthorChange(e) {
        this.setState({ author: e.target.value })
    }

    handleUpdate() {
        let updateBook =
        {
            _id:this.state.id,
            bookName: this.state.name,
            bookDescription: this.state.description,
            count: this.state.count,
            author: this.state.author
        }
        const config = {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        }
        fetch('http://localhost:2000/products/update', {
            method: 'post',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updateBook),
        }).then(res => res.json())
            .then(data => {
                this.setState({ show: false })
            });
        let libraryItems = [];
        libraryItems = this.props.items;
        libraryItems.map((data, key) => {
            if(data._id === this.state.id){
                data._id = this.state.id;
                data.bookName= this.state.name,
                data.bookDescription= this.state.description,
                data.count= this.state.count,
                data.author= this.state.author
            }
        });
        console.log('after update',libraryItems)
        this.props.createNewBook(libraryItems)
    }

    delete(item) {
        console.log('ite', item)
        fetch('http://localhost:2000/products/delete', {
            method: 'post',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(item),
        }).then(res => res.json())
            .then(data => {
                window.location.href = '/dashboard'
            });
    }

    onChangeSearch(e) {
        this.setState({ search: e.target.value.substr(0, 20) })
    }

    listItems() {
        let filteredBooks = this.props.items.filter(
            (books) => {
                return books.bookName.indexOf(this.state.search) !== -1;
            }
        );
        return filteredBooks.map(item => {
            return (
                <div className="listBooks" key={item._id}>
                    <p className="bookNames"> {item.bookName}</p>
                    <div className="count"><p className="bookNames">Available:  {item.count}</p></div>
                    <div>
                        <button className="btnLib editLib" type="button" onClick={() => this.updateItem(item)}>Edit</button>
                        <button className="btnLib deleteLib" type="button" onClick={() => this.delete(item)} >Delete</button>
                    </div>
                </div>
            );
        });
    }
    render() {
        const customStyles = {
            content: {
                top: '50%',
                left: '50%',
                right: 'auto',
                bottom: 'auto',
                marginRight: '-50%',
                transform: 'translate(-50%, -50%)'
            }
        };
        return (
            <div>
                <input type="text" placeholder="Search.." name="search" onChange={(e) => this.onChangeSearch(e)} value={this.state.search} />
                {this.listItems()}

                <Modal
                    isOpen={this.state.show}
                    onAfterOpen={this.afterOpenModal}
                    onRequestClose={this.closeModal}
                    style={customStyles}
                    contentLabel="Example Modal"
                >
                    <div class="container">
                        <h1>Add New Book</h1>
                        <hr />

                        <label for="bookName"><b>Book Name</b></label>
                        <input type="text" placeholder="Enter Book Name" name="bookName" onChange={(e) => this.bookNameChange(e)} value={this.state.name} />

                        <label for="bookDescription"><b>Book Description</b></label>
                        <input type="text" placeholder="Book Description" name="bookDescription" onChange={(e) => this.bookDescriptionChange(e)} value={this.state.description} />

                        <label for="count"><b>Number of books</b></label>
                        <input type="text" placeholder="Number of books.." name="count" onChange={(e) => this.bookCountChange(e)} value={this.state.count} />
                        <hr />
                        <label for="author"><b>Author</b></label>
                        <input type="text" placeholder="Author Name" name="count" onChange={(e) => this.bookAuthorChange(e)} value={this.state.author} />

                        <button type="button" class="addEditBtn" onClick={this.handleUpdate}>Edit Book</button>
                    </div>
                </Modal>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        items: state.bookStore.libraryItems,
    };
};

const mapDispatchToProps = (dispatch) => {
    return {
        getLibraryBooks: (obj) => dispatch(getLibraryBooks(obj)),
        editBook: (obj) => dispatch(editBook(obj)),
        createNewBook: (obj) => dispatch(createNewBook(obj))
    };
};

//export default BooksList;
export default connect(mapStateToProps, mapDispatchToProps)(BooksList);
