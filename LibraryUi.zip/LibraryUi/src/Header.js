import React, { Component } from 'react';
import './App.css';

class Header extends Component {
  addBook(){
    window.location.href = '/addNewBook'
  }
  render() {
    return (
      <div>
      <div className="header">
        <h1>Book Library System</h1>
        <button className="btnLib editLib" type="button" onClick={()=>this.addBook()}>Add New Book</button>
    </div>
    </div>
    );
  }
}

export default Header;
