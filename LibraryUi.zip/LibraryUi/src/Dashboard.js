import React, { Component } from 'react';
import './App.css';
import Header from './Header.js';
import BooksList from './BooksList'

class DashBoard extends Component {
    render() {
      return (
        <div className="App">
        <div className="superdiv">
         <Header/>
         <BooksList/>
        </div>
      </div>
      );
    }
  }
  
  export default DashBoard;